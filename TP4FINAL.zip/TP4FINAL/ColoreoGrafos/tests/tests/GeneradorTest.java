package tests;

import org.junit.*;

import coloreoGrafos.Generador;


public class GeneradorTest {
	@Test
	public void queGeneraCorrectamenteDadosNyProb(){
		Generador.genRanProb(5, 50,"generadoPorProbabilidadPorArista.in");
	}
	
	@Test
	public void queGeneraCorrectamenteDadosNyPorcAdy(){
		Generador.genRanPorcAdy(5, 40,"generadoPorPorcentajeDeAdyacencia.in");
	}
	
	@Test
	public void queGeneraCorrectamenteRegDadosNyGrado(){
		Generador.genRegGrado(5, 4, "generadoPorGradoDado.in");
	}
	
	@Test
	public void queGeneraCorrectamenteRegDadosNyPorcAdy(){
		Generador.genRegPorcAdy(11, 0, "generadoPorPorcentajeDeAdyacenciaReg.in");
	}
	
	@Test
	public void queGeneraCorrectamenteNPartito(){
		Generador.genNPartito(7, 3, "generadoPorNpartitos.in");
	}
	
	@Test
	public void generaGrafoA600PorcAdy40(){
		Generador.genRanPorcAdy(600, 40, ".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA40PorcAdy.in");
	}
	
	@Test
	public void generaGrafoA600PorcAdy60(){
		Generador.genRanPorcAdy(600, 60, ".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA60PorcAdy.in");
	}
	
	@Test
	public void generaGrafoA600PorcAdy90(){
		Generador.genRanPorcAdy(600, 90, ".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA90PorcAdy.in");
	}

	@Test
	public void generaGrafoReg1000PorcAdy50(){
		Generador.genRegPorcAdy(1000, 50, ".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg50PorcAdy.in");
	}
	
	@Test
	public void generaGrafoReg1000PorcAdy75(){
		Generador.genRegPorcAdy(1000, 75, ".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg75PorcAdy.in");
	}
}
