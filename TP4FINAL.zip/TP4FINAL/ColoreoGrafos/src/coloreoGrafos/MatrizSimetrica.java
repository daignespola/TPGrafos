package coloreoGrafos;

public class MatrizSimetrica {
	private boolean[] matriz;
	private int dim;
	
	public MatrizSimetrica(int dim){
		this.matriz = new boolean[(int) (Math.pow(dim, 2) - dim)/2];
		this.dim = dim;
	}
	
	public boolean getContenido(int i, int j){
		if(j>i)
			return matriz[i*this.dim+j-((int)Math.pow(i, 2)+3*i+2)/2];
		
		if(j==i)
			return false;
		
		return matriz[j*this.dim+i-((int)Math.pow(j, 2)+3*j+2)/2];
	}
	
	public void setContenido(int i,int j){
		// F * N + C � ( F 2 + 3 * F + 2) / 2
		if(j > i)
			matriz[i*this.dim+j-((int)Math.pow(i, 2)+3*i+2)/2]=true;
		else
			matriz[j*this.dim+i-((int)Math.pow(j, 2)+3*j+2)/2]=true;
		
			
	}

	public boolean[] getMatriz() {
		return matriz;
	}
}
