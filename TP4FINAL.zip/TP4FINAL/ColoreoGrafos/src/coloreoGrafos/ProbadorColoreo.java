package coloreoGrafos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class ProbadorColoreo {

	private MatrizSimetrica matrizAdyacencia;
	private int nodosColoreados[];
	private int cantNodos;
	private int cantAristas;
	private int cantColores;
	
	public ProbadorColoreo(String pathGrafo, String pathColoreo) {
		FileReader fr = null;
		try {
			File archivo = new File(pathGrafo);
			fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
			
			// Lectura archivo nodos adyacentes
			String linea = br.readLine();
			String datos[] = linea.split(" ");
			cantNodos = Integer.parseInt(datos[0]);
			cantAristas = Integer.parseInt(datos[1]);
			matrizAdyacencia=new MatrizSimetrica(cantNodos);

			for(int i=0; i<cantAristas; i++) {
				linea = br.readLine();
				datos = linea.split(" ");
				matrizAdyacencia.setContenido(Integer.parseInt(datos[0]),Integer.parseInt(datos[1]));
			}
			
			// Lectura archivo nodos con colores 
			archivo = new File(pathColoreo);
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			linea=br.readLine();
			datos=linea.split(" ");
			cantColores = Integer.parseInt(datos[1]);
			nodosColoreados=new int[cantNodos];
			for(int i=0; i<cantNodos; i++) {
				linea = br.readLine();
				datos = linea.split(" ");
				
				nodosColoreados[Integer.parseInt(datos[0])] = Integer.parseInt(datos[1]); 
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(fr != null)
					fr.close();
			}
			catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public boolean verifica() {
		int i,j;
		cantNodos = nodosColoreados.length;
		
		int color;
		for(i=0; i<cantNodos; i++) {
			 color = nodosColoreados[i];
			 
			 if(color>this.cantColores)//para verificar que el nodo no haya sido pintado mas de una vez
				 return false;
			 if(color==0)//para verificar que el nodo fue coloreado
				 return false;
			 for(j=i+1; j<cantNodos; j++)
				 if(matrizAdyacencia.getContenido(i, j)==true && color==nodosColoreados[j])
					 return false;
		}
		return true;
	}
}
