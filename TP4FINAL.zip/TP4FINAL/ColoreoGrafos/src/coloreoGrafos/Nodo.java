package coloreoGrafos;

public class Nodo implements Comparable < Nodo >  {
	
	int numero;
	int color;
	int grado;
	
	public Nodo(int indice, int color, int grado )
	{
		this.numero= indice;
		this.color= color;
		this.grado= grado;
	}

	@Override
	public int compareTo(Nodo nodo) {//ordena de menor a Mayor
		if(this.grado>nodo.grado)
			return 1;
		if(this.grado==nodo.grado)
			return 0;
		
		return -1;
	}
	
}
