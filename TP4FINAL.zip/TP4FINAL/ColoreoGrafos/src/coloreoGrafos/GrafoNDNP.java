package coloreoGrafos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Arrays;


public class GrafoNDNP {
	private MatrizSimetrica matrizAdyacencia;
	private int cantNodos;
	private int cantAristas;
	private Nodo[] nodo;
	private int cantColores;
	private double porcAdyacencia;
	private int gradoMax;
	private int gradoMin;

	public GrafoNDNP(String archivo)
	{
	    FileReader fr = null;
	    BufferedReader br = null;
	    try {	        
	         fr = new FileReader (archivo);
	         br = new BufferedReader(fr);
	       
	         String[] datos = br.readLine().split(" "); 	
	         cantNodos = Integer.parseInt( datos[0] );
	         cantAristas = Integer.parseInt( datos[1] );
	         porcAdyacencia = Integer.parseInt( datos[2] );
	         gradoMax = Integer.parseInt( datos[3] );
	         gradoMin = Integer.parseInt( datos[4] );
	         nodo = new Nodo[cantNodos];
    		 for(int i=0; i<cantNodos;i++)
    			 nodo[i]= new Nodo(i,0,0); //Inicializo cada nodo enumerandolo, colocandole color 0 y grado 0.
    		 matrizAdyacencia=new MatrizSimetrica(cantNodos); 
    	
	         for(int i=0; i<cantAristas; i++)
        	 {
        		 datos = br.readLine().split(" ");   
        		 matrizAdyacencia.setContenido(Integer.parseInt(datos[0]),Integer.parseInt(datos[1]));
    
        		 nodo[Integer.parseInt(datos[0])].grado++; //Incremento el grado, tras realizar la adyacencia
        		 nodo[Integer.parseInt(datos[1])].grado++;
             }  
        	 
	    }
	    catch(Exception e){
		         e.printStackTrace();
		  }finally{
		         try{                    
		            if( null != fr ){   
		               fr.close();     
		            }                  
		         }catch (Exception e2){ 
		            e2.printStackTrace();
		         }
		      }		
	}

	public void colorearSecuencialAleatorio() {
		int i, color;
		ordenarRandom();
		cantColores = 0;
		for(i=0; i<cantNodos; i++) {
			color = 1;
			while(!sePuedeColorearOrdenado(nodo[i], color)){
				color++;				
			}
				
			nodo[i].color = color;
			if(color > cantColores)
				cantColores = color;
		}
	}	
	
	private void ordenarRandom() {
		int random,min=0,max=cantNodos;
		Nodo auxNodo;
		
		for (int i = 0; i < cantNodos; i++) {

			random=(int)(Math.random()*(max-min))+min;
			auxNodo=nodo[i];
			nodo[i]=nodo[random];
			nodo[random]=auxNodo;
		}
		
		
	}

	public void colorearWelshPowell(){
		int color;
		cantColores=0;
		ordenarPorMayorGrado();
		for(int i=0; i<cantNodos; i++) {
			color = 1;
			while(!sePuedeColorearOrdenado(this.nodo[i], color))
				color++;
			nodo[i].color = color;
			if(color > cantColores)
				cantColores = color;
		}
	}
	
	public void colorearMatula(){
		int color;
		cantColores=0;
		ordenarPorMenorGrado();
		for(int i=0; i<cantNodos; i++) {
			color = 1;
			while(!sePuedeColorearOrdenado(this.nodo[i], color))
				color++;
			nodo[i].color = color;
			if(color > cantColores)
				cantColores = color;
		}
	}
	
	private void ordenarPorMenorGrado() {
		Nodo auxNodo;
		int random,max=cantNodos,min=0;
		//obtengo grados de todos los nodos.
		for(int i=0;i<cantNodos;i++){
			for(int j=0;j<cantNodos;j++){
				this.nodo[i].numero=i;
				if(matrizAdyacencia.getContenido(i, j)==true){
					this.nodo[i].grado+=1;
					//grados[i]++;
				}	
				
			}
		}
		//desordeno ese vector
		for (int i = 0; i < cantNodos; i++) {

			random=(int)(Math.random()*(max-min))+min;
			auxNodo=nodo[i];
			nodo[i]=nodo[random];
			nodo[random]=auxNodo;
		}
		
		//ordeno el vector
		
		Arrays.sort(this.nodo);
		
	}

	private void ordenarPorMayorGrado() {
		Nodo auxNodo;
		int random,max=cantNodos,min=0;
		//obtengo grados de todos los nodos.
		for(int i=0;i<cantNodos;i++){
			for(int j=0;j<cantNodos;j++){
				this.nodo[i].numero=i;
				if(matrizAdyacencia.getContenido(i, j)==true){
					this.nodo[i].grado+=1;
					//grados[i]++;
				}	
				
			}
		}
		//desordeno ese vector
		for (int i = 0; i < cantNodos; i++) {

			random=(int)(Math.random()*(max-min))+min;
			auxNodo=nodo[i];
			nodo[i]=nodo[random];
			nodo[random]=auxNodo;
		}
		
		//ordeno el vector

		//VERSION 2
		Arrays.sort(this.nodo);

		
	}

	private boolean esAdyacente(Nodo nodo1, Nodo nodo2) {
		return matrizAdyacencia.getContenido(nodo1.numero,nodo2.numero);
	}
	
	private boolean sePuedeColorearOrdenado(Nodo n, int color) {
		int i=0; 
		if(n.color != 0) //si el nodo fue coloreado 
			return false;      //ya esta pintado
		while(i < cantNodos) {
			if(nodo[i].color == color) {  //si el nodo a colorear es adyacente a un nodo ya pintado de ese
				if(esAdyacente(nodo[i],n))  //color, no lo podr� colorear
					return false;
			}
			
			i++;
		}
		return true;
	}
	
	public void escribirArchivo (String archivo){ 
		
        FileWriter fichero = null;
        PrintWriter pw = null;  
		try
        {		
        	fichero = new FileWriter(archivo);
            pw = new PrintWriter(fichero);     
            String linea;
            linea=this.cantNodos+" "+this.cantColores+" "+this.cantAristas+" "+(int)this.porcAdyacencia+" "+this.gradoMax+" "+this.gradoMin;
            pw.println(linea);   
            for(int i=0; i<cantNodos; i++)       
                pw.println(nodo[i].numero + " " + nodo[i].color);//Grabo cada nodo con su color.

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           try {
           if (null != fichero)
              fichero.close();
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }			
	}
	
	public void analisisSecuencial(String Path){
		
		 int cantidadCorridas=10000;
		 int numeroCorridaMin=0;
		 int cantColoresMin=0;
		 	FileWriter fichero = null;
	        PrintWriter pw = null;  
			try
	        {		
	        	fichero = new FileWriter(Path);
	            pw = new PrintWriter(fichero);  
	            colorearSecuencialAleatorio();
	            pw.println(this.cantColores);
	            cantColoresMin=cantColores;
	            numeroCorridaMin=1;
	            despintarNodos();
	            for (int i = 2; i <= cantidadCorridas; i++) {
	    			colorearSecuencialAleatorio();
	    			pw.println(this.cantColores);
	    			if(cantColores<cantColoresMin){
	    				cantColoresMin=cantColores;
	    				numeroCorridaMin=i;
	    			}
	    			despintarNodos();
	    		}
	           pw.print("Numero Cromatico: "+ cantColoresMin +" en la corrida: "+ numeroCorridaMin);
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	           try {
	           if (null != fichero)
	              fichero.close();
	           } catch (Exception e2) {
	              e2.printStackTrace();
	           }
	        }	
	        }
	public void analisisWelshPowell(String Path){
		
		int cantidadCorridas=10000;
		 int numeroCorridaMin=0;
		 int cantColoresMin=0;
		 	FileWriter fichero = null;
	        PrintWriter pw = null; 
			try
	        {		
	        	fichero = new FileWriter(Path);
	            pw = new PrintWriter(fichero);  
	            
	            colorearWelshPowell();
	            pw.println(this.cantColores);
	            cantColoresMin=cantColores;
	            numeroCorridaMin=1;
	            despintarNodos();
	            for (int i = 2; i <= cantidadCorridas; i++) {
	    			colorearWelshPowell();
	    			pw.println(this.cantColores);
	    			if(cantColores<cantColoresMin){
	    				cantColoresMin=cantColores;
	    				numeroCorridaMin=i;
	    			}
	    			despintarNodos();
	    		}
	           pw.print("Numero Cromatico: "+ cantColoresMin +" en la corridad: "+ numeroCorridaMin);
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	           try {
	           if (null != fichero)
	              fichero.close();
	           } catch (Exception e2) {
	              e2.printStackTrace();
	           }
	        }
	}
	public void analisisMatula(String Path){
			int cantidadCorridas=10000;
			int numeroCorridaMin;
			int cantColoresMin;
		 	FileWriter fichero = null;
	        PrintWriter pw = null; 
			try
	        {		
	        	fichero = new FileWriter(Path);
	            pw = new PrintWriter(fichero);  
	            colorearMatula();
	            pw.println(this.cantColores);
	            cantColoresMin=cantColores;
	            numeroCorridaMin=1;
	            
	            despintarNodos();
	            
	            for (int i = 2; i <=cantidadCorridas; i++) {
	    			colorearMatula();
	    			pw.println(this.cantColores);
	    			if(cantColores<cantColoresMin){
	    				cantColoresMin=cantColores;
	    				numeroCorridaMin=i;
	    			}
	    			
	    			despintarNodos();
	    		}
	           pw.print("Numero Cromatico: "+ cantColoresMin +" en la corrida: "+ numeroCorridaMin);
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	           try {
	           if (null != fichero)
	              fichero.close();
	           } catch (Exception e2) {
	              e2.printStackTrace();
	           }
	        }		 
	}
	
	private void despintarNodos() {
		for (int i = 0; i < nodo.length; i++) {
			nodo[i].color=0;
			nodo[i].grado=0;
			nodo[i].numero=i;
		}
		
	}
}
