package tests;

import org.junit.Assert;
import org.junit.Test;

import coloreoGrafos.Generador;
import coloreoGrafos.GrafoNDNP;
import coloreoGrafos.ProbadorColoreo;

public class GrafoNDNPTest {
	@Test
	public void coloreoCorrectoPorSecuencialAleatorio(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA40PorcAdy.in";
		String dirColoreo=".\\Ejecuci�n de Prueba\\Salida Obtenida\\600NodosA40PorcAdySecAleatorio.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		grafo.colorearSecuencialAleatorio();
		grafo.escribirArchivo(dirColoreo);
		
		ProbadorColoreo probador=new ProbadorColoreo(dirGrafo, dirColoreo);
		Assert.assertTrue(probador.verifica());
	}
	
	@Test
	public void coloreoCorrectoPorMatula(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA40PorcAdy.in";
		String dirColoreo=".\\Ejecuci�n de Prueba\\Salida Obtenida\\600NodosA40PorcAdyMatula.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		grafo.colorearMatula();
		grafo.escribirArchivo(dirColoreo);
		
		ProbadorColoreo probador=new ProbadorColoreo(dirGrafo, dirColoreo);
		Assert.assertTrue(probador.verifica());
	}
	
	@Test
	public void coloreoCorrectoPorWelshPowell(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA40PorcAdy.in";
		String dirColoreo=".\\Ejecuci�n de Prueba\\Salida Obtenida\\600NodosA40PorcAdyWelshPowell.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		grafo.colorearWelshPowell();
		grafo.escribirArchivo(dirColoreo);
		
		ProbadorColoreo probador=new ProbadorColoreo(dirGrafo, dirColoreo);
		Assert.assertTrue(probador.verifica());
	}
	
	@Test
	public void generarAnalisisDeColoreoSecuencialRandom(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA40PorcAdy.in";
		String dirAnalisis= ".\\\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisSecuencialRandom600_40.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		
		grafo.analisisSecuencial(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA60PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisSecuencialRandom600_60.out";
		
		GrafoNDNP grafo1 = new GrafoNDNP(dirGrafo);
		
		grafo1.analisisSecuencial(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA90PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisSecuencialRandom600_90.out";
		
		GrafoNDNP grafo2 = new GrafoNDNP(dirGrafo);
		
		grafo2.analisisSecuencial(dirAnalisis);
	}
	
	@Test
	public void generarAnalisisDeColoreoSecuencialRegular(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg50PorcAdy.in";
		String dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisSecuencialRegular1000_50.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		
		grafo.analisisSecuencial(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg75PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisSecuencialRegular1000_75.out";
		
		GrafoNDNP grafo1 = new GrafoNDNP(dirGrafo);
		
		grafo1.analisisSecuencial(dirAnalisis);
	}
	
	@Test
	public void generarAnalisisDeColoreoMatula(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA40PorcAdy.in";
		String dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisMatulaRandom600_40.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		
		grafo.analisisMatula(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA60PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisMatulaRandom600_60.out";
		
		GrafoNDNP grafo1 = new GrafoNDNP(dirGrafo);
		
		grafo1.analisisMatula(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA90PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisMatulaRandom600_90.out";
		
		GrafoNDNP grafo2 = new GrafoNDNP(dirGrafo);
		
		grafo2.analisisMatula(dirAnalisis);
	}
	
	@Test
	public void generarAnalisisDeColoreoMatulaRegular(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg50PorcAdy.in";
		String dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisMatulaRegular1000_50.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		
		grafo.analisisMatula(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg75PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisMatulaRegular1000_75.out";
		
		GrafoNDNP grafo1 = new GrafoNDNP(dirGrafo);
		
		grafo1.analisisMatula(dirAnalisis);
	}
	
	@Test
	public void generarAnalisisDeColoreoWelshPowell(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA40PorcAdy.in";
		String dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisWelshPowellRandom600_40.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		
		grafo.analisisWelshPowell(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA60PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisWelshPowellRandom600_60.out";
		
		GrafoNDNP grafo1 = new GrafoNDNP(dirGrafo);
		
		grafo1.analisisWelshPowell(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\600NodosA90PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisWelshPowellRandom600_90.out";
		
		GrafoNDNP grafo2 = new GrafoNDNP(dirGrafo);
		
		grafo2.analisisWelshPowell(dirAnalisis);
	}
	
	@Test
	public void generarAnalisisDeColoreoWelshPowellRegular(){
		String dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg50PorcAdy.in";
		String dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisWelshPowellRegular1000_50.out";
		
		GrafoNDNP grafo = new GrafoNDNP(dirGrafo);
		
		grafo.analisisWelshPowell(dirAnalisis);
		
		dirGrafo=".\\Preparaci�n de la Prueba\\Programa Probador\\Lote de Prueba del PP\\Entrada\\1000NodosReg75PorcAdy.in";
		dirAnalisis= ".\\Ejecuci�n de Prueba\\Salida Obtenida\\AnalisisWelshPowellRegular1000_75.out";
		
		GrafoNDNP grafo1 = new GrafoNDNP(dirGrafo);
		
		grafo1.analisisWelshPowell(dirAnalisis);
	}
}
