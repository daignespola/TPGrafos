package tests;

import org.junit.*;

import coloreoGrafos.MatrizSimetrica;

public class MatrizSimetricaTests {
	
	@Test
	public void queConstruyecorrectamente(){
		MatrizSimetrica mSim = new MatrizSimetrica(5);
		MatrizSimetrica mSim2 = new MatrizSimetrica(10);
		Assert.assertTrue(mSim.getMatriz().length == 10);
		Assert.assertTrue(mSim2.getMatriz().length == 45);
	}
	
	@Test
	public void queGrabaValorCorrectamente(){
		MatrizSimetrica mSim = new MatrizSimetrica(5);
		mSim.setContenido(0,1);
		Assert.assertTrue(mSim.getMatriz()[0]);
		MatrizSimetrica mSim2 = new MatrizSimetrica(5);
		mSim2.setContenido(1,2);
		Assert.assertTrue(mSim2.getMatriz()[4]);
		MatrizSimetrica mSim3 = new MatrizSimetrica(5);
		mSim3.setContenido(3,4);
		Assert.assertTrue(mSim3.getMatriz()[9]);
	}
	
	@Test
	public void queLeeValorCorrectamente(){
		MatrizSimetrica mSim = new MatrizSimetrica(5);
		mSim.setContenido(0,1);
		Assert.assertTrue(mSim.getContenido(0,1));
		MatrizSimetrica mSim2 = new MatrizSimetrica(5);
		mSim2.setContenido(1,2);
		Assert.assertTrue(mSim2.getContenido(1,2));
		MatrizSimetrica mSim3 = new MatrizSimetrica(5);
		mSim3.setContenido(3,4);
		Assert.assertTrue(mSim3.getContenido(3,4));
	}
	
	
}
